#include "freecam.hpp"

#include "core/memory/Hooks.hpp"
#include <bedrocktools/memory/Signatures.hpp>
#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/AttackEvent.hpp>
#include <bedrocktools/sdk/client/ClientInstance.hpp>
#include <bedrocktools/sdk/render/LevelRenderer.hpp>
#include <bedrocktools/sdk/world/Actor.hpp>
#include <pl/ModMenu.hpp>

#include <algorithm>
#include <cmath>
#include <chrono>

static FreeCamModule* g_freeCam = nullptr;
static void (*g_turnOriginal)(void*, bedrocktools::sdk::Vec2*) = nullptr;

static void freeCamTurnHook(void* self, bedrocktools::sdk::Vec2* delta) {
    if (!g_freeCam || !g_freeCam->enabled || !delta) {
        if (g_turnOriginal) g_turnOriginal(self, delta);
        return;
    }

    // Keep the real player's rotation untouched. FreeCam applies the same
    // look delta to its virtual camera rotation instead.
    g_freeCam->applyTurnDelta(*delta);
}

static const char* buttonId(const char* name) {
    static thread_local std::string id;
    id = std::string("bedrocktools.FreeCam.") + name;
    return id.c_str();
}

FreeCamModule::FreeCamModule()
    : Module("FreeCam", "Free camera. The player stays at the starting position and gameplay input is blocked.") {
    g_freeCam = this;
    keybind = 0;
}

FreeCamModule::~FreeCamModule() {
    unregisterButtons();
    if (m_attackSubscription) {
        bedrocktools::events::bus().unsubscribe(m_attackSubscription);
        m_attackSubscription = 0;
    }
    if (g_freeCam == this) g_freeCam = nullptr;
}

void FreeCamModule::onInit() {
    if (!m_turnHooked) {
        const auto address = bedrocktools::memory::resolve(
            bedrocktools::memory::SignatureId::LocalPlayerApplyTurnDelta
        );
        if (address) {
            m_turnHooked = bedrocktools::hooks::install(
                reinterpret_cast<void*>(address),
                reinterpret_cast<void*>(freeCamTurnHook),
                reinterpret_cast<void**>(&g_turnOriginal)
            );
        }
    }

    if (!m_attackSubscription) {
        m_attackSubscription = bedrocktools::events::bus().subscribe<bedrocktools::events::AttackEvent>(
            [this](bedrocktools::events::AttackEvent& event) {
                if (enabled) event.cancel();
            },
            bedrocktools::events::EventPriority::High
        );
    }
}

void FreeCamModule::onEnable() {
    startCamera();
    resetMoveState();
    updateButtons();
}

void FreeCamModule::onDisable() {
    stopCamera();
    resetMoveState();
    unregisterButtons();
}

void FreeCamModule::startCamera() {
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) return;

    auto* player = client->localPlayer();
    if (!player) return;

    auto* renderer = client->levelRenderer();
    auto* rendererPlayer = renderer ? renderer->playerRenderer() : nullptr;

    m_anchor = player->position();
    m_rotation = player->rotation();

    if (rendererPlayer) {
        m_camera = rendererPlayer->cameraPosition();
    } else {
        m_camera = m_anchor;
        m_camera.y += 1.62f;
    }

    m_haveCamera = true;
}

void FreeCamModule::stopCamera() {
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) {
        m_haveCamera = false;
        return;
    }

    auto* player = client->localPlayer();
    if (player) {
        player->setPosition(m_anchor);
        player->setRotation(m_rotation);
    }

    auto* renderer = client->levelRenderer();
    auto* rendererPlayer = renderer ? renderer->playerRenderer() : nullptr;
    if (rendererPlayer && m_haveCamera) {
        rendererPlayer->cameraPosition() = m_camera;
    }

    m_haveCamera = false;
}

void FreeCamModule::resetMoveState() {
    m_forward = false;
    m_back = false;
    m_left = false;
    m_right = false;
    m_up = false;
    m_down = false;

}

void FreeCamModule::setMoveState(const char* direction, bool state) {
    if (std::string(direction) == "Forward") m_forward = state;
    else if (std::string(direction) == "Back") m_back = state;
    else if (std::string(direction) == "Left") m_left = state;
    else if (std::string(direction) == "Right") m_right = state;
    else if (std::string(direction) == "Up") m_up = state;
    else if (std::string(direction) == "Down") m_down = state;
}

void FreeCamModule::updateButtons() {
    const char* names[] = {"Forward", "Back", "Left", "Right", "Up", "Down"};

    for (const char* name : names) {
        const std::string id = std::string("bedrocktools.FreeCam.") + name;
        const std::string label = std::string("FreeCam ") + name;

        pl::modmenu::ButtonBuilder(id, label)
            .moduleId("bedrocktools.FreeCam")
            .behavior(pl::modmenu::ButtonBehavior::Toggle)
            .onEvent([this, name](std::string_view, pl::modmenu::ButtonEvent event, float value) {
                if (event == pl::modmenu::ButtonEvent::StateChanged) {
                    setMoveState(name, value > 0.5f);
                }
            })
            .registerButton();
    }
}

void FreeCamModule::unregisterButtons() {
    const char* names[] = {"Forward", "Back", "Left", "Right", "Up", "Down"};
    for (const char* name : names) {
        pl::modmenu::unregisterButton(buttonId(name));
    }
}

void FreeCamModule::applyTurnDelta(const bedrocktools::sdk::Vec2& delta) {
    m_rotation.x += delta.x;
    m_rotation.y += delta.y;
    m_rotation.x = std::clamp(m_rotation.x, -89.9f, 89.9f);
}

void FreeCamModule::onFrame() {
    if (!enabled || !m_haveCamera) return;

    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) return;

    auto* player = client->localPlayer();
    if (!player) return;

    auto* renderer = client->levelRenderer();
    auto* rendererPlayer = renderer ? renderer->playerRenderer() : nullptr;
    if (!rendererPlayer) return;

    // Keep the real player stationary and prevent its rotation from following
    // the free camera.
    player->setPosition(m_anchor);
    player->setRotation(m_rotation);

    // Camera movement is intentionally independent of collision.
    // Use the camera yaw to determine horizontal forward/right vectors.
    const float yawRad = m_rotation.y * 0.01745329251994329577f;
    const float sinYaw = std::sin(yawRad);
    const float cosYaw = std::cos(yawRad);

    float forward = (m_forward ? 1.0f : 0.0f) - (m_back ? 1.0f : 0.0f);
    float strafe  = (m_right ? 1.0f : 0.0f) - (m_left ? 1.0f : 0.0f);
    float vertical = (m_up ? 1.0f : 0.0f) - (m_down ? 1.0f : 0.0f);

    if (forward != 0.0f || strafe != 0.0f || vertical != 0.0f) {
        const float length = std::sqrt(forward * forward + strafe * strafe + vertical * vertical);
        if (length > 1.0f) {
            forward /= length;
            strafe /= length;
            vertical /= length;
        }

        // X/Z axes follow the conventional Bedrock yaw orientation.
        m_camera.x += (sinYaw * forward + cosYaw * strafe) * m_speed;
        m_camera.z += (cosYaw * forward - sinYaw * strafe) * m_speed;
        m_camera.y += vertical * m_speed;
    }

    const float dx = m_camera.x - m_anchor.x;
    const float dy = m_camera.y - m_anchor.y;
    const float dz = m_camera.z - m_anchor.z;

    const float distanceSquared = dx * dx + dy * dy + dz * dz;
    const float maxDistanceSquared = m_maxDistance * m_maxDistance;

    if (distanceSquared > maxDistanceSquared) {
        const float scale = m_maxDistance / std::sqrt(distanceSquared);
        m_camera.x = m_anchor.x + dx * scale;
        m_camera.y = m_anchor.y + dy * scale;
        m_camera.z = m_anchor.z + dz * scale;
    }

    rendererPlayer->cameraPosition() = m_camera;
}

bool FreeCamModule::onMouseEvent(int, bool) {
    // FreeCam is observation-only: consume gameplay mouse/touch-button input.
    return enabled;
}

void FreeCamModule::onKeybindEvent(const std::string& key, bool isDown) {
    if (key == "keybind" && isDown) {
        setMasterEnabled(!masterEnabled);
    }
}

void FreeCamModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("m_speed")) m_speed = j["m_speed"].get<float>();
    if (j.contains("m_maxDistance")) m_maxDistance = j["m_maxDistance"].get<float>();
}

void FreeCamModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["m_speed"] = m_speed;
    j["m_maxDistance"] = m_maxDistance;
}
