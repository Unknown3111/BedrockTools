#pragma once

#include "../Module.hpp"
#include <bedrocktools/sdk/Types.hpp>
#include <bedrocktools/events/EventBus.hpp>
#include <string>

class FreeCamModule : public Module {
public:
    FreeCamModule();
    ~FreeCamModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onFrame() override;
    bool onMouseEvent(int button, bool isDown) override;
    void onKeybindEvent(const std::string& key, bool isDown) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    void setMoveState(const char* direction, bool state);
    void applyTurnDelta(const bedrocktools::sdk::Vec2& delta);

private:
    void resetMoveState();
    void updateButtons();
    void unregisterButtons();
    void startCamera();
    void stopCamera();

    bedrocktools::sdk::Vec3 m_anchor{};
    bedrocktools::sdk::Vec3 m_camera{};
    bedrocktools::sdk::Vec2 m_rotation{};
    bool m_haveCamera = false;

    bool m_forward = false;
    bool m_back = false;
    bool m_left = false;
    bool m_right = false;
    bool m_up = false;
    bool m_down = false;

    float m_speed = 0.25f;
    float m_maxDistance = 128.0f;

    bool m_turnHooked = false;
    bedrocktools::events::Subscription m_attackSubscription = 0;
};

