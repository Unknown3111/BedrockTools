# BedrockTools FreeCam v0.2

This is a native BedrockTools module integrated into the normal module registry.

## Intended behavior

- Enable **FreeCam** from LeviLauncher/BedrockTools.
- The player's position is continuously restored to the position where FreeCam started.
- The player's rotation is also controlled by the virtual camera rotation.
- Normal gameplay mouse/button input is consumed while FreeCam is active.
- Attack events are still handled by BedrockTools; this module consumes mouse input.
- The camera position is moved independently of player collision.
- The camera is bounded to a configurable radius from the starting point.
- The six FreeCam movement buttons (Forward/Back/Left/Right/Up/Down) are registered through the existing PreLoader mod-menu button API.
- Normal look/touch input is redirected to the FreeCam rotation through the existing `LocalPlayerApplyTurnDelta` signature.
- Default camera speed is 0.25 blocks/frame and default radius is 128 blocks.

## Important

This is a first working implementation. The BedrockTools source does not expose a keyboard-state API, so the initial mobile-friendly implementation uses six toggleable mod-menu buttons for movement. The camera look path uses the existing BedrockTools turn-delta hook.

The exact meaning of the two rotation components is version-dependent. If the target Minecraft build uses a different convention, the pitch/yaw assignment may need adjustment.

## Build

Use the existing GitHub Actions workflow in `.github/workflows/build.yml`. The generated artifact contains the `.levipack` produced by `scripts/package_levipack.py`.
