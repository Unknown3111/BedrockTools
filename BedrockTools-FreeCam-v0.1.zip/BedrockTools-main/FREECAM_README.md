# BedrockTools Free Cam — first implementation

This adds a `Free Cam` module to BedrockTools.

## Intended behavior

- The module is toggled through the normal BedrockTools module/keybind system.
- The player's saved position is restored every frame.
- Normal movement input is converted into camera displacement.
- The camera can move independently while the player remains at the saved position.
- Mouse clicks are consumed while Free Cam is enabled.
- Attack events are cancelled while Free Cam is enabled.
- Camera movement is limited to a configurable radius around the saved player position (default: 256 blocks).
- Disabling Free Cam returns the camera to the player position.

## Important first-version limitation

This first implementation intentionally uses the existing player movement pipeline to obtain movement deltas. It does not yet implement a separate native keyboard/touch movement controller or an exact loaded-chunk query. Those can be added after the basic implementation is verified on the target Bedrock version.

## Files added

- `src/modules/visual/freecam.hpp`
- `src/modules/visual/freecam.cpp`

`src/modules/visual/ModuleRegistry.cpp` is updated to register the module.
