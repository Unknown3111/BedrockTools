#pragma once

void registerModulesWithLauncher();
