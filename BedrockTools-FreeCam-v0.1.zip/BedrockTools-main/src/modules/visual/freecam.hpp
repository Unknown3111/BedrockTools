#pragma once

#include "../Module.hpp"
#include <bedrocktools/sdk/Types.hpp>
#include <cstddef>

class FreeCamModule : public Module {
public:
    FreeCamModule();
    ~FreeCamModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onFrame() override;
    bool onMouseEvent(int button, bool isDown) override;

    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

private:
    bedrocktools::sdk::Vec3 m_anchor{};
    bedrocktools::sdk::Vec3 m_camera{};
    bedrocktools::sdk::Vec3 m_originalCamera{};
    bool m_haveCamera = false;
    bool m_haveAnchor = false;
    bool m_restoring = false;
    float m_maxDistance = 256.0f;

    void captureState();
    void restorePlayerPosition();
};
