#include "freecam.hpp"

#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/AttackEvent.hpp>
#include <bedrocktools/events/LocalPlayerTickEvent.hpp>
#include <bedrocktools/sdk/client/ClientInstance.hpp>
#include <bedrocktools/sdk/render/LevelRenderer.hpp>
#include <bedrocktools/sdk/Offsets.hpp>
#include <bedrocktools/sdk/Memory.hpp>
#include <algorithm>
#include <cmath>

namespace {
FreeCamModule* g_freeCam = nullptr;

static bedrocktools::sdk::Player* localPlayer() {
    auto* client = bedrocktools::sdk::ClientInstance::current();
    return client ? client->localPlayer() : nullptr;
}

static bedrocktools::sdk::Vec3& playerPositionRef(bedrocktools::sdk::Player* player) {
    auto* component = player->stateVectorComponent();
    return bedrocktools::sdk::field<bedrocktools::sdk::Vec3>(component, 0);
}

static bedrocktools::sdk::LevelRendererPlayer* rendererPlayer() {
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) return nullptr;
    auto* renderer = client->levelRenderer();
    if (!renderer) return nullptr;
    return renderer->playerRenderer();
}

static float distanceSquared(const bedrocktools::sdk::Vec3& a,
                             const bedrocktools::sdk::Vec3& b) {
    const float x = a.x - b.x;
    const float y = a.y - b.y;
    const float z = a.z - b.z;
    return x * x + y * y + z * z;
}

static bedrocktools::sdk::Vec3 clampToRadius(
    const bedrocktools::sdk::Vec3& point,
    const bedrocktools::sdk::Vec3& origin,
    float radius) {
    const float d2 = distanceSquared(point, origin);
    if (d2 <= radius * radius || d2 <= 0.0001f) return point;

    const float scale = radius / std::sqrt(d2);
    return {
        origin.x + (point.x - origin.x) * scale,
        origin.y + (point.y - origin.y) * scale,
        origin.z + (point.z - origin.z) * scale
    };
}
}

FreeCamModule::FreeCamModule()
    : Module("Free Cam", "Moves the camera independently while keeping the player in place.") {
    g_freeCam = this;
}

FreeCamModule::~FreeCamModule() {
    if (g_freeCam == this) g_freeCam = nullptr;
}

void FreeCamModule::onInit() {
    // FreeCam uses only SDK objects already exposed by BedrockTools.
    // No additional signature hook is required for the first implementation.
    bedrocktools::events::bus().subscribe<bedrocktools::events::AttackEvent>(
        [](auto& event) {
            if (g_freeCam && g_freeCam->enabled) event.cancel();
        });
}

void FreeCamModule::captureState() {
    auto* player = localPlayer();
    auto* renderer = rendererPlayer();
    if (!player || !renderer) {
        m_haveAnchor = false;
        m_haveCamera = false;
        return;
    }

    m_anchor = player->position();
    m_camera = renderer->cameraPosition();
    m_originalCamera = m_camera;
    m_haveAnchor = true;
    m_haveCamera = true;
}

void FreeCamModule::onEnable() {
    captureState();
}

void FreeCamModule::restorePlayerPosition() {
    if (!m_haveAnchor || m_restoring) return;
    auto* player = localPlayer();
    if (!player || !player->stateVectorComponent()) return;

    m_restoring = true;
    playerPositionRef(player) = m_anchor;
    m_restoring = false;
}

void FreeCamModule::onDisable() {
    if (m_haveCamera) {
        if (auto* renderer = rendererPlayer()) renderer->cameraPosition() = m_originalCamera;
    }
    restorePlayerPosition();
    m_haveAnchor = false;
    m_haveCamera = false;
}

void FreeCamModule::onFrame() {
    if (!enabled) return;

    auto* player = localPlayer();
    auto* renderer = rendererPlayer();
    if (!player || !renderer || !player->stateVectorComponent()) return;

    if (!m_haveAnchor || !m_haveCamera) {
        captureState();
        return;
    }

    // Minecraft still processes the normal movement controls. We convert the
    // resulting player displacement into camera displacement, then put the
    // real player back at the saved anchor point.
    const auto currentPlayer = player->position();
    const auto delta = bedrocktools::sdk::Vec3{
        currentPlayer.x - m_anchor.x,
        currentPlayer.y - m_anchor.y,
        currentPlayer.z - m_anchor.z
    };

    m_camera.x += delta.x;
    m_camera.y += delta.y;
    m_camera.z += delta.z;
    m_camera = clampToRadius(m_camera, m_anchor, m_maxDistance);

    renderer->cameraPosition() = m_camera;
    restorePlayerPosition();
}

bool FreeCamModule::onMouseEvent(int, bool) {
    // Mouse clicks are gameplay actions; consume them while FreeCam is active.
    return enabled;
}

void FreeCamModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("m_maxDistance")) m_maxDistance = std::clamp(j["m_maxDistance"].get<float>(), 16.0f, 1024.0f);
}

void FreeCamModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["m_maxDistance"] = m_maxDistance;
}
